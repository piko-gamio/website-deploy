import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Programs } from './components/Programs';
import { Coaches } from './components/Coaches';
import { Facilities } from './components/Facilities';
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';

export function App() {
  return (
    <div className="bg-cricket-dark min-h-screen text-white overflow-x-hidden">
      <Navbar />
      <Hero />
      <About />
      <Programs />
      <Coaches />
      <Facilities />
      <Testimonials />
      <Contact />
      <Footer />
    </div>
  );
}
