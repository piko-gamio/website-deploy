import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Award, Star } from 'lucide-react';

const coaches = [
  {
    name: 'Rajesh Shrestha',
    role: 'Head Coach & Batting Specialist',
    experience: '20+ years',
    specialty: 'Batting',
    achievements: 'Former Nepal National Team Captain, ICC Level 3 Certified Coach',
    description: 'Master of classical batting technique with deep knowledge of modern T20 strokeplay. Has mentored 50+ national-level players.',
    initials: 'RS',
    gradient: 'from-emerald-400 to-green-600',
  },
  {
    name: 'Binod Maharjan',
    role: 'Pace Bowling Coach',
    experience: '15+ years',
    specialty: 'Fast Bowling',
    achievements: 'Former national pace bowler, ECB Level 2 Coach, Sports Biomechanics Expert',
    description: 'Specializes in fast bowling biomechanics, swing, seam and reverse swing techniques. Pioneer of pace bowling development in Nepal.',
    initials: 'BM',
    gradient: 'from-cricket-gold to-amber-500',
  },
  {
    name: 'Sanjay Tamang',
    role: 'Spin Bowling Coach',
    experience: '18+ years',
    specialty: 'Spin Bowling',
    achievements: 'Nepal\'s top spin bowling analyst, ACC certified, 200+ wickets in domestic cricket',
    description: 'Expert in off-spin, leg-spin, and wrist-spin variations. Known for turning ordinary bowlers into match-winning spinners.',
    initials: 'ST',
    gradient: 'from-blue-400 to-indigo-500',
  },
  {
    name: 'Priya Karki',
    role: 'Fielding & Fitness Coach',
    experience: '12+ years',
    specialty: 'Fielding & Fitness',
    achievements: 'Sports Science degree from Tribhuvan University, National fitness consultant',
    description: 'Transforms athletes with cutting-edge fitness programs, agility training, and world-class fielding drills.',
    initials: 'PK',
    gradient: 'from-rose-400 to-pink-600',
  },
  {
    name: 'Dipak Thapa',
    role: 'Wicketkeeping Coach',
    experience: '16+ years',
    specialty: 'Wicketkeeping',
    achievements: 'Former Nepal wicketkeeper, 150+ dismissals in first-class cricket, ICC coach',
    description: 'The art of wicketkeeping perfected — footwork, glovework, and reading the game from behind the stumps.',
    initials: 'DT',
    gradient: 'from-teal-400 to-cyan-600',
  },
  {
    name: 'Ankit Basnet',
    role: 'Mental Conditioning Coach',
    experience: '10+ years',
    specialty: 'Sports Psychology',
    achievements: 'M.Sc Sports Psychology, worked with Nepal Olympic Committee',
    description: 'Builds unbreakable mental resilience. Specializes in pressure handling, visualization, and peak performance mindset.',
    initials: 'AB',
    gradient: 'from-violet-400 to-purple-600',
  },
  {
    name: 'Rajan Gurung',
    role: 'All-Rounder Development Coach',
    experience: '14+ years',
    specialty: 'All-Round Skills',
    achievements: 'Versatile former player, ACC Level 2, developed 30+ all-rounders for Nepal',
    description: 'Creates complete cricketers who excel with both bat and ball. Master of game-sense and tactical awareness.',
    initials: 'RG',
    gradient: 'from-orange-400 to-red-500',
  },
  {
    name: 'Kiran Rai',
    role: 'Youth Development Coach',
    experience: '11+ years',
    specialty: 'Junior Coaching',
    achievements: 'Specialized in youth development, CAN certified, built Nepal U-19 pipeline',
    description: 'Nurtures young talent with patience and passion. Recognized for identifying and developing raw cricket talent in Nepal.',
    initials: 'KR',
    gradient: 'from-lime-400 to-green-500',
  },
];

export function Coaches() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="coaches" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-cricket-dark via-[#0b2118] to-cricket-dark" />
      
      <motion.div
        animate={{ x: [-20, 20, -20], y: [-10, 10, -10] }}
        transition={{ duration: 14, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute top-1/3 right-0 w-80 h-80 rounded-full bg-cricket-light/3 blur-3xl"
      />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            className="text-cricket-gold text-sm font-light uppercase tracking-[0.3em]"
          >
            Expert Coaches
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2 }}
            className="text-4xl md:text-5xl font-serif font-bold text-white mt-4 mb-6"
          >
            Learn From the Best
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.4 }}
            className="text-white/40 font-light max-w-2xl mx-auto"
          >
            Our coaching staff comprises former international players, certified ICC coaches,
            and sports science professionals dedicated to your development.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {coaches.map((coach, i) => (
            <motion.div
              key={coach.name}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.1 + i * 0.1 }}
              className="glass rounded-3xl p-6 hover:bg-white/[0.08] transition-all duration-500 group"
            >
              {/* Avatar */}
              <div className="flex items-center gap-4 mb-4">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${coach.gradient} flex items-center justify-center text-white font-bold text-lg shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                  {coach.initials}
                </div>
                <div>
                  <h3 className="text-white font-semibold text-sm">{coach.name}</h3>
                  <p className="text-cricket-gold text-xs font-light">{coach.specialty}</p>
                </div>
              </div>

              <p className="text-white/60 text-xs font-medium mb-2">{coach.role}</p>
              <p className="text-white/40 text-xs font-light leading-relaxed mb-4">{coach.description}</p>

              <div className="flex items-center gap-2 mb-3">
                <Award size={12} className="text-cricket-gold" />
                <span className="text-white/50 text-xs font-light">{coach.experience} experience</span>
              </div>

              <div className="pt-3 border-t border-white/5">
                <div className="flex items-start gap-2">
                  <Star size={10} className="text-cricket-gold mt-0.5 shrink-0" />
                  <p className="text-white/30 text-[10px] font-light leading-relaxed">{coach.achievements}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
