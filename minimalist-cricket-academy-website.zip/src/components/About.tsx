import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Target, Trophy, Heart, Mountain } from 'lucide-react';

const features = [
  {
    icon: Target,
    title: 'Precision Training',
    desc: 'Advanced biomechanics analysis and technique refinement programs',
  },
  {
    icon: Trophy,
    title: 'Championship Legacy',
    desc: 'Producing national-level players and tournament champions',
  },
  {
    icon: Heart,
    title: 'Passion Driven',
    desc: 'Nurturing the love for cricket from grassroots to professional',
  },
  {
    icon: Mountain,
    title: 'Himalayan Spirit',
    desc: 'Training at altitude for enhanced fitness and mental fortitude',
  },
];

export function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="about" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-cricket-dark via-[#091f14] to-cricket-dark" />
      
      {/* Floating accent */}
      <motion.div
        animate={{ y: [-30, 30, -30], rotate: [0, 5, 0] }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute top-20 right-10 w-72 h-72 rounded-full bg-cricket-gold/3 blur-3xl"
      />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <motion.span
              initial={{ opacity: 0, x: -20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6 }}
              className="text-cricket-gold text-sm font-light uppercase tracking-[0.3em]"
            >
              Our Story
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-4xl md:text-5xl font-serif font-bold text-white mt-4 mb-6 leading-tight"
            >
              Where Champions
              <br />
              <span className="text-cricket-light">Begin Their Journey</span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-white/50 font-light leading-relaxed mb-6"
            >
              Founded in the heart of Hattiban, Lalitpur, our cricket academy has been the cradle 
              of Nepal's emerging cricket talent. Surrounded by the majestic Himalayan foothills, 
              we offer world-class training facilities combined with the discipline and wisdom 
              of Nepali sporting tradition.
            </motion.p>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="text-white/50 font-light leading-relaxed"
            >
              Our academy specializes in holistic player development — from technical batting 
              and bowling mastery to mental conditioning and match strategy. Every student who 
              walks through our gates becomes part of a legacy of excellence.
            </motion.p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.3 + i * 0.15 }}
                className="glass rounded-2xl p-6 hover:bg-white/[0.08] transition-all duration-500 group"
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cricket-light/20 to-cricket-gold/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon size={22} className="text-cricket-gold" />
                </div>
                <h3 className="text-white font-medium text-sm mb-2">{feature.title}</h3>
                <p className="text-white/40 text-xs font-light leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
