import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Zap, Users, Star, Crown, Clock, ArrowRight } from 'lucide-react';

const programs = [
  {
    icon: Zap,
    title: 'Junior Academy',
    age: 'Ages 6–12',
    duration: '3 months',
    description: 'Foundation skills, hand-eye coordination, basic batting, bowling and fielding techniques.',
    features: ['Basic Technique', 'Fun Drills', 'Team Play', 'Fitness Basics'],
    color: 'from-emerald-500 to-green-600',
  },
  {
    icon: Users,
    title: 'Youth Development',
    age: 'Ages 13–17',
    duration: '6 months',
    description: 'Advanced skill development, competitive play, match strategy and mental conditioning.',
    features: ['Advanced Batting', 'Bowling Variations', 'Match Simulation', 'Fitness Training'],
    color: 'from-cricket-light to-emerald-500',
    featured: true,
  },
  {
    icon: Star,
    title: 'Senior Elite',
    age: 'Ages 18+',
    duration: '12 months',
    description: 'Professional-level training with personalized coaching plans and performance analytics.',
    features: ['Pro Coaching', 'Video Analysis', 'Diet Plans', 'Tournament Prep'],
    color: 'from-cricket-gold to-amber-500',
  },
  {
    icon: Crown,
    title: 'Pro Masterclass',
    age: 'All Ages',
    duration: 'Intensive',
    description: 'Specialized sessions with former international players and certified coaches.',
    features: ['1-on-1 Sessions', 'Expert Analysis', 'Career Guidance', 'Mental Training'],
    color: 'from-amber-500 to-orange-500',
  },
];

export function Programs() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="programs" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-cricket-dark via-[#0a1e13] to-cricket-dark" />
      
      <motion.div
        animate={{ y: [-20, 20, -20] }}
        transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute bottom-0 left-0 w-96 h-96 rounded-full bg-cricket-light/3 blur-3xl"
      />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            className="text-cricket-gold text-sm font-light uppercase tracking-[0.3em]"
          >
            Training Programs
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2 }}
            className="text-4xl md:text-5xl font-serif font-bold text-white mt-4 mb-6"
          >
            Tailored for Every Level
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.4 }}
            className="text-white/40 font-light max-w-2xl mx-auto"
          >
            From first-time players to aspiring professionals, we have a program designed
            to elevate your game to the next level.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {programs.map((program, i) => (
            <motion.div
              key={program.title}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 + i * 0.15 }}
              className={`glass rounded-3xl p-6 hover:bg-white/[0.08] transition-all duration-500 group relative ${
                program.featured ? 'ring-1 ring-cricket-light/30 lg:scale-105' : ''
              }`}
            >
              {program.featured && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-cricket-light to-emerald-500 text-white text-xs font-medium">
                  Most Popular
                </div>
              )}
              
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${program.color} bg-opacity-20 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300`}
                style={{ background: `linear-gradient(135deg, rgba(22,163,74,0.15), rgba(212,160,23,0.15))` }}
              >
                <program.icon size={24} className="text-cricket-gold" />
              </div>
              
              <h3 className="text-white font-semibold text-lg mb-1">{program.title}</h3>
              <div className="flex items-center gap-3 mb-4">
                <span className="text-cricket-light text-xs font-light">{program.age}</span>
                <span className="text-white/20">•</span>
                <span className="flex items-center gap-1 text-white/40 text-xs">
                  <Clock size={10} />
                  {program.duration}
                </span>
              </div>
              <p className="text-white/40 text-sm font-light leading-relaxed mb-5">{program.description}</p>
              
              <div className="space-y-2 mb-6">
                {program.features.map((f) => (
                  <div key={f} className="flex items-center gap-2 text-white/50 text-xs font-light">
                    <div className="w-1 h-1 rounded-full bg-cricket-gold" />
                    {f}
                  </div>
                ))}
              </div>
              
              <a
                href="#contact"
                className="flex items-center gap-2 text-cricket-gold text-sm font-light group-hover:gap-3 transition-all duration-300"
              >
                Join Program <ArrowRight size={14} />
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
