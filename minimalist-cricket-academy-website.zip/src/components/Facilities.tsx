import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Dumbbell, Tv, Droplets, ShieldCheck, Wifi, Tent } from 'lucide-react';

const facilities = [
  {
    icon: Tent,
    title: 'Indoor Nets',
    desc: 'Professional indoor practice nets with bowling machines and video analysis setup',
  },
  {
    icon: Dumbbell,
    title: 'Fitness Center',
    desc: 'Fully equipped gym with strength, cardio, and functional training equipment',
  },
  {
    icon: Tv,
    title: 'Video Analysis Lab',
    desc: 'High-speed cameras and software for detailed technique breakdown',
  },
  {
    icon: Droplets,
    title: 'Turf Wickets',
    desc: 'Multiple grass and artificial turf wickets for match-quality practice',
  },
  {
    icon: ShieldCheck,
    title: 'Medical Support',
    desc: 'On-site physiotherapy, injury prevention programs, and recovery facilities',
  },
  {
    icon: Wifi,
    title: 'Smart Training',
    desc: 'Wearable tech integration for tracking performance metrics in real-time',
  },
];

export function Facilities() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="facilities" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-cricket-dark via-[#091c12] to-cricket-dark" />
      
      <motion.div
        animate={{ y: [20, -20, 20] }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute top-1/2 left-1/4 w-72 h-72 rounded-full bg-emerald-500/3 blur-3xl"
      />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <motion.span
              initial={{ opacity: 0, x: -20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              className="text-cricket-gold text-sm font-light uppercase tracking-[0.3em]"
            >
              World-Class Facilities
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.2 }}
              className="text-4xl md:text-5xl font-serif font-bold text-white mt-4 mb-6 leading-tight"
            >
              Train Like a
              <br />
              <span className="text-cricket-light">Professional</span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.4 }}
              className="text-white/50 font-light leading-relaxed mb-8"
            >
              Our academy in Hattiban features state-of-the-art infrastructure designed 
              to provide the best training environment for cricketers of all levels. 
              From advanced bowling machines to smart performance tracking — we've 
              invested in everything you need to excel.
            </motion.p>

            {/* Facility visual */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.5 }}
              className="glass rounded-3xl p-8 relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-cricket-light/5 to-cricket-gold/5" />
              <div className="relative">
                <div className="text-6xl mb-4">🏟️</div>
                <h3 className="text-white font-semibold text-xl mb-2">Hattiban Cricket Ground</h3>
                <p className="text-white/40 text-sm font-light">
                  Our sprawling ground in the foothills features a full-size pitch, 
                  practice areas, and a pavilion with stunning mountain views.
                </p>
                <div className="flex gap-4 mt-4">
                  <div className="text-center">
                    <div className="text-cricket-gold font-bold text-lg">3</div>
                    <div className="text-white/30 text-xs">Practice Nets</div>
                  </div>
                  <div className="text-center">
                    <div className="text-cricket-gold font-bold text-lg">2</div>
                    <div className="text-white/30 text-xs">Turf Pitches</div>
                  </div>
                  <div className="text-center">
                    <div className="text-cricket-gold font-bold text-lg">1</div>
                    <div className="text-white/30 text-xs">Indoor Hall</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {facilities.map((facility, i) => (
              <motion.div
                key={facility.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.2 + i * 0.1 }}
                className="glass rounded-2xl p-5 hover:bg-white/[0.08] transition-all duration-500 group"
              >
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cricket-light/15 to-cricket-gold/15 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                  <facility.icon size={18} className="text-cricket-gold" />
                </div>
                <h3 className="text-white font-medium text-sm mb-1">{facility.title}</h3>
                <p className="text-white/35 text-xs font-light leading-relaxed">{facility.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
