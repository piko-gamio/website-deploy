import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Aarav Pandey',
    role: 'U-19 Nepal Team Player',
    quote: 'Hattiban Cricket Academy transformed my game completely. The coaches helped me refine my batting technique and gave me the confidence to play at the national level.',
    initials: 'AP',
  },
  {
    name: 'Suman Adhikari',
    role: 'District Level All-Rounder',
    quote: 'The spin bowling coaching here is extraordinary. Coach Sanjay\'s methods are unique and effective. I went from an average bowler to a match-winning spinner.',
    initials: 'SA',
  },
  {
    name: 'Nisha Sharma',
    role: 'Women\'s Cricket Team Captain',
    quote: 'As a female cricketer, I found incredible support and equal opportunities here. The academy truly believes in nurturing talent regardless of gender.',
    initials: 'NS',
  },
];

export function Testimonials() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-cricket-dark via-[#0a1f15] to-cricket-dark" />
      
      <motion.div
        animate={{ x: [-15, 15, -15] }}
        transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute top-1/4 right-1/4 w-96 h-96 rounded-full bg-cricket-gold/3 blur-3xl"
      />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            className="text-cricket-gold text-sm font-light uppercase tracking-[0.3em]"
          >
            Success Stories
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2 }}
            className="text-4xl md:text-5xl font-serif font-bold text-white mt-4"
          >
            Voices of Champions
          </motion.h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 + i * 0.15 }}
              className="glass rounded-3xl p-8 hover:bg-white/[0.08] transition-all duration-500 relative group"
            >
              <Quote size={32} className="text-cricket-gold/20 mb-4" />
              <p className="text-white/50 text-sm font-light leading-relaxed mb-6 italic">
                "{t.quote}"
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cricket-light to-cricket-gold flex items-center justify-center text-white text-xs font-bold">
                  {t.initials}
                </div>
                <div>
                  <div className="text-white font-medium text-sm">{t.name}</div>
                  <div className="text-white/30 text-xs font-light">{t.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
