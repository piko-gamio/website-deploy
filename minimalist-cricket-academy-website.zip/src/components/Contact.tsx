import { motion, useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle } from 'lucide-react';

export function Contact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <section id="contact" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-cricket-dark via-[#091e14] to-cricket-dark" />
      
      <motion.div
        animate={{ y: [-25, 25, -25] }}
        transition={{ duration: 11, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute bottom-1/4 left-1/3 w-80 h-80 rounded-full bg-cricket-light/3 blur-3xl"
      />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            className="text-cricket-gold text-sm font-light uppercase tracking-[0.3em]"
          >
            Get in Touch
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2 }}
            className="text-4xl md:text-5xl font-serif font-bold text-white mt-4 mb-6"
          >
            Start Your Journey
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.4 }}
            className="text-white/40 font-light max-w-2xl mx-auto"
          >
            Ready to take your cricket to the next level? Reach out to us for enrollment,
            trial sessions, or any queries about our programs.
          </motion.p>
        </div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.3 }}
            className="lg:col-span-2 space-y-6"
          >
            {[
              { icon: MapPin, label: 'Location', value: 'Hattiban, Lalitpur\nBagmati Province, Nepal' },
              { icon: Phone, label: 'Phone', value: '+977 01-5550123\n+977 9841234567' },
              { icon: Mail, label: 'Email', value: 'info@hattibancricket.com.np\nadmissions@hattibancricket.com.np' },
              { icon: Clock, label: 'Training Hours', value: 'Mon–Fri: 6:00 AM – 6:00 PM\nSat–Sun: 7:00 AM – 5:00 PM' },
            ].map((item, i) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.4 + i * 0.1 }}
                className="glass rounded-2xl p-5 flex items-start gap-4 hover:bg-white/[0.06] transition-all duration-300"
              >
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cricket-light/15 to-cricket-gold/15 flex items-center justify-center shrink-0">
                  <item.icon size={18} className="text-cricket-gold" />
                </div>
                <div>
                  <div className="text-white/60 text-xs uppercase tracking-wider mb-1">{item.label}</div>
                  <div className="text-white/80 text-sm font-light whitespace-pre-line">{item.value}</div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.5 }}
            className="lg:col-span-3 glass rounded-3xl p-8"
          >
            {submitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center justify-center h-full py-16"
              >
                <CheckCircle size={64} className="text-cricket-light mb-4" />
                <h3 className="text-white font-semibold text-xl mb-2">Message Sent!</h3>
                <p className="text-white/40 text-sm font-light">We'll get back to you within 24 hours.</p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid md:grid-cols-2 gap-5">
                  <div>
                    <label className="text-white/50 text-xs font-light uppercase tracking-wider mb-2 block">Full Name</label>
                    <input
                      type="text"
                      required
                      placeholder="Your name"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm font-light placeholder:text-white/20 focus:outline-none focus:border-cricket-light/50 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="text-white/50 text-xs font-light uppercase tracking-wider mb-2 block">Phone</label>
                    <input
                      type="tel"
                      required
                      placeholder="+977 98XXXXXXXX"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm font-light placeholder:text-white/20 focus:outline-none focus:border-cricket-light/50 transition-colors"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-white/50 text-xs font-light uppercase tracking-wider mb-2 block">Email</label>
                  <input
                    type="email"
                    required
                    placeholder="you@email.com"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm font-light placeholder:text-white/20 focus:outline-none focus:border-cricket-light/50 transition-colors"
                  />
                </div>
                <div>
                  <label className="text-white/50 text-xs font-light uppercase tracking-wider mb-2 block">Program Interest</label>
                  <select
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm font-light focus:outline-none focus:border-cricket-light/50 transition-colors appearance-none"
                  >
                    <option value="" className="bg-cricket-dark">Select a program</option>
                    <option value="junior" className="bg-cricket-dark">Junior Academy (Ages 6–12)</option>
                    <option value="youth" className="bg-cricket-dark">Youth Development (Ages 13–17)</option>
                    <option value="senior" className="bg-cricket-dark">Senior Elite (Ages 18+)</option>
                    <option value="pro" className="bg-cricket-dark">Pro Masterclass</option>
                  </select>
                </div>
                <div>
                  <label className="text-white/50 text-xs font-light uppercase tracking-wider mb-2 block">Message</label>
                  <textarea
                    rows={4}
                    placeholder="Tell us about your cricket experience and goals..."
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm font-light placeholder:text-white/20 focus:outline-none focus:border-cricket-light/50 transition-colors resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-cricket-light to-emerald-600 text-white font-medium flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-green-500/20 transition-all duration-300 hover:scale-[1.02]"
                >
                  <Send size={16} />
                  Send Inquiry
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
