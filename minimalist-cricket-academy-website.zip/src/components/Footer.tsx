import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

export function Footer() {
  return (
    <footer className="relative py-16 overflow-hidden">
      <div className="absolute inset-0 bg-cricket-dark" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-10 mb-12">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cricket-light to-cricket-gold flex items-center justify-center">
                <span className="text-white text-lg">🏏</span>
              </div>
              <div>
                <span className="text-white font-semibold text-lg">Hattiban</span>
                <span className="text-cricket-gold font-light text-lg ml-1">Cricket Academy</span>
              </div>
            </div>
            <p className="text-white/30 text-sm font-light leading-relaxed max-w-md">
              Nepal's premier cricket training institution, producing champions from the 
              heart of Lalitpur since our establishment. Building the future of Nepali cricket, 
              one player at a time.
            </p>
          </div>

          <div>
            <h4 className="text-white/60 text-xs uppercase tracking-wider mb-4">Quick Links</h4>
            <div className="space-y-2">
              {['About Us', 'Programs', 'Coaches', 'Facilities', 'Contact'].map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase().replace(' ', '')}`}
                  className="block text-white/30 text-sm font-light hover:text-cricket-gold transition-colors"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-white/60 text-xs uppercase tracking-wider mb-4">Programs</h4>
            <div className="space-y-2">
              {['Junior Academy', 'Youth Development', 'Senior Elite', 'Pro Masterclass'].map((p) => (
                <a
                  key={p}
                  href="#programs"
                  className="block text-white/30 text-sm font-light hover:text-cricket-gold transition-colors"
                >
                  {p}
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-white/20 text-xs font-light">
            © {new Date().getFullYear()} Hattiban Cricket Academy. All rights reserved.
          </p>
          <motion.p 
            className="text-white/20 text-xs font-light flex items-center gap-1"
            whileHover={{ scale: 1.05 }}
          >
            Made with <Heart size={10} className="text-red-400" /> in Lalitpur, Nepal
          </motion.p>
        </div>
      </div>
    </footer>
  );
}
