import { motion } from 'framer-motion';
import { ChevronDown, MapPin } from 'lucide-react';

export function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-cricket-dark via-[#0d2418] to-cricket-dark" />
      
      {/* Floating orbs */}
      <motion.div
        animate={{ y: [-20, 20, -20], x: [-10, 10, -10] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-cricket-light/5 blur-3xl"
      />
      <motion.div
        animate={{ y: [20, -20, 20], x: [10, -10, 10] }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-cricket-gold/5 blur-3xl"
      />
      <motion.div
        animate={{ y: [15, -25, 15] }}
        transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute top-1/3 right-1/3 w-64 h-64 rounded-full bg-emerald-500/5 blur-3xl"
      />

      {/* Cricket ball floating elements */}
      <motion.div
        animate={{ y: [-15, 15, -15], rotate: [0, 360] }}
        transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute top-32 right-20 text-5xl opacity-10"
      >
        🏏
      </motion.div>
      <motion.div
        animate={{ y: [10, -20, 10], rotate: [0, -180, -360] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute bottom-40 left-16 text-4xl opacity-10"
      >
        🏏
      </motion.div>

      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)',
        backgroundSize: '60px 60px'
      }} />

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-light mb-8"
        >
          <MapPin size={14} className="text-cricket-gold" />
          <span className="text-white/60 text-sm font-light">Hattiban, Lalitpur, Nepal</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold text-white leading-tight mb-6"
        >
          Master the
          <br />
          <span className="bg-gradient-to-r from-cricket-light via-emerald-400 to-cricket-gold bg-clip-text text-transparent animate-gradient">
            Gentleman's Game
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.7 }}
          className="text-white/50 text-lg md:text-xl font-light max-w-2xl mx-auto mb-12 leading-relaxed"
        >
          Nepal's premier cricket academy nestled in the serene hills of Hattiban.
          Where passion meets precision, and champions are forged.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.9 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <a
            href="#programs"
            className="px-8 py-4 rounded-full bg-gradient-to-r from-cricket-light to-emerald-600 text-white font-medium hover:shadow-2xl hover:shadow-green-500/20 transition-all duration-500 hover:scale-105"
          >
            Explore Programs
          </a>
          <a
            href="#about"
            className="px-8 py-4 rounded-full glass-light text-white/80 font-light hover:text-white transition-all duration-300 hover:scale-105"
          >
            Learn More
          </a>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
          className="mt-20 grid grid-cols-3 gap-8 max-w-lg mx-auto"
        >
          {[
            { number: '15+', label: 'Years' },
            { number: '500+', label: 'Students' },
            { number: '12', label: 'Expert Coaches' },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-cricket-gold">{stat.number}</div>
              <div className="text-white/40 text-xs font-light mt-1 uppercase tracking-wider">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <ChevronDown size={24} className="text-white/30" />
        </motion.div>
      </motion.div>
    </section>
  );
}
